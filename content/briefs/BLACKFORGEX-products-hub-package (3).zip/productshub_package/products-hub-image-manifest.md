# BLACKFORGEX — PRODUCTS HUB PAGE
## Image Manifest (Free, Commercial-Use-Licensed — Pexels)

**Important context for this page:** A product catalog page showing actual garment photography is different from a UI/banner section. Here, product photos naturally show varied real-world colors (a red jacket, a yellow rain shell, etc.) — that's normal and expected for a product page, not a brand-color violation. The brand's red/black/white/grey palette still governs the page's UI (buttons, backgrounds, text), just not the product photography itself.

**How to use these:** Direct hotlink URLs — reference them directly in `<img src="...">` tags. No download or local file needed.

---

## GROUP 1 — OUTERWEAR & JACKETS (7 products)

Strong real photo matches found for this group:

**Waterproof Jackets:**
`https://images.pexels.com/photos/33461164/pexels-photo-33461164.jpeg?auto=compress&cs=tinysrgb&w=700`
(Hiker in yellow rain jacket, Torla-Ordesa, Spain)

**Rain Jackets:**
`https://images.pexels.com/photos/4633868/pexels-photo-4633868.jpeg?auto=compress&cs=tinysrgb&w=700`
(Person in yellow rain jacket near waterfall)

**Softshell Jackets:**
`https://images.pexels.com/photos/34733420/pexels-photo-34733420.jpeg?auto=compress&cs=tinysrgb&w=700`
(Man hiking in rocky terrain, technical jacket)

**Hardshell Jackets:**
`https://images.pexels.com/photos/31348061/pexels-photo-31348061.jpeg?auto=compress&cs=tinysrgb&w=700`
(Hiker in winter gear ascending snowy mountain)

**Puffer Jackets:**
`https://images.pexels.com/photos/7009605/pexels-photo-7009605.jpeg?auto=compress&cs=tinysrgb&w=700`
(Man in red winter jacket with ski poles)

**Fleece Jackets:**
`https://images.pexels.com/photos/134068/pexels-photo-134068.jpeg?auto=compress&cs=tinysrgb&w=700`
(Woman in green zip hooded jacket on snowy mountain)

**Windbreakers:**
`https://images.pexels.com/photos/7010110/pexels-photo-7010110.jpeg?auto=compress&cs=tinysrgb&w=700`
(Woman in red windbreaker jacket, studio-style shot)

**Down Jackets:**
`https://images.pexels.com/photos/17252408/pexels-photo-17252408.jpeg?auto=compress&cs=tinysrgb&w=700`
(Man in winter puffer/down jacket on snowy mountain path)

---

## GROUP 2 — BOTTOMS (4 products)

**Honest note:** Free stock has very few dedicated "cargo pants," "outdoor pants," "insulated pants" or "convertible pants" product-style photos without a lot of unrelated lifestyle context. Recommend styled placeholders for this entire group until real product photography is available:
- "Cargo Pants — Product Photo Placeholder"
- "Outdoor Pants — Product Photo Placeholder"
- "Insulated Pants — Product Photo Placeholder"
- "Convertible Pants — Product Photo Placeholder"

---

## GROUP 3 — ACTIVITY-SPECIFIC APPAREL (4 products)

**Hiking Apparel:**
`https://images.pexels.com/photos/19143813/pexels-photo-19143813.jpeg?auto=compress&cs=tinysrgb&w=700`
(Man in outdoor gear admiring mountain landscape)

**Ski Wear:**
`https://images.pexels.com/photos/6263447/pexels-photo-6263447.jpeg?auto=compress&cs=tinysrgb&w=700`
(Man in ski wear on the mountain with trekking poles)

**Snowboard Apparel:**
Use the same ski wear image as a placeholder (6263447) — free stock rarely distinguishes snowboard-specific apparel from ski wear visually. Flag for a real photo later.

**Base Layers:**
**Honest note:** No good free match found — recommend a styled placeholder: "Base Layers — Product Photo Placeholder"

---

## GROUP 4 — WORKWEAR & TACTICAL (3 products)

**Honest note:** This group needs a dedicated search pass not yet done in this manifest (workwear, uniforms, tactical clothing, and safety wear were not searched for this page — time was spent on the outdoor/jacket group first, which had the most product-relevant hits). Recommend styled placeholders for all four until a follow-up image search or real photos are available:
- "Workwear — Product Photo Placeholder"
- "Uniforms — Product Photo Placeholder"
- "Tactical Clothing — Product Photo Placeholder"
- "Safety Wear — Product Photo Placeholder"

---

## GROUP 5 — SPORTSWEAR & EVERYDAY BASICS (4 products)

**Honest note:** Same as Group 4 — not yet searched for this page. Recommend styled placeholders:
- "Sportswear — Product Photo Placeholder"
- "Activewear — Product Photo Placeholder"
- "Hoodies — Product Photo Placeholder"
- "T-Shirts — Product Photo Placeholder"

---

## HERO IMAGE

**File label:** hero-outdoor-jacket-lifestyle
**URL:** `https://images.pexels.com/photos/34733420/pexels-photo-34733420.jpeg?auto=compress&cs=tinysrgb&w=1600`
**Description:** Man hiking in rugged terrain wearing technical outerwear — reuse of the softshell jacket image at hero size, with dark overlay for text readability.

---

## STYLING FOR PLACEHOLDER CARDS

For any product without a real image match, use a consistent placeholder style rather than mixing photos and blank boxes — e.g. light-grey (`--bg-light`) background, centered uppercase label in `--body` grey, same rounded corners as the photo cards, so the grid still looks intentional even where photos are missing.

## PRIORITY RECOMMENDATION

This hub page has real photos for 7 of 20 products (all in the Outerwear group) and one activity-specific photo. The other 12 are placeholders. **Two options:**
1. Launch with placeholders for the unmatched 12 and do a follow-up image search pass specifically for workwear, tactical, sportswear and basics categories (these likely have decent free stock available, just not yet searched).
2. Wait for real BlackForgeX product photography before launching this page, since it's the page most likely to benefit from actual product shots (buyers browsing a catalog expect to see the real product, more than they'd expect on a service page).

## LICENSE NOTE FOR CLAUDE CODE

All images above are from Pexels, free for commercial use, no attribution required. Not competitor images, not AI-generated. Verify each URL loads before finalizing.
