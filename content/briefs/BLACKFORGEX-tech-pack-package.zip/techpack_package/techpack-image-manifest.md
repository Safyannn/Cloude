# BLACKFORGEX — TECH PACK & SAMPLE DEVELOPMENT PAGE
## Image Manifest

**IMPORTANT — read this first:** The competitor's tech pack page uses actual **technical flat sketches** (line drawings of garments with measurement callouts, front/back/side views). These are a specific professional deliverable — they are NOT stock photos, and generic stock photography cannot represent them convincingly. A photo of fabric or a sewing machine in a "Jacket Tech Pack" card would look wrong and confuse the visitor.

**Recommendation:** For the 8 tech-pack-type cards, use clean, styled PLACEHOLDER blocks (not stock photos) until real BlackForgeX technical sketches are available. This is the one page where a labeled placeholder genuinely looks more professional than a mismatched stock image.

---

## SECTION → IMAGE MAPPING

### Hero Section
**Option A (recommended):** A real photo of a designer/technician working on garment technical drawings or measurements — this fits the hero without needing an actual tech pack sketch.
**File label:** hero-designer-technical-drawing
**URL:** `https://images.pexels.com/photos/606918/pexels-photo-606918.jpeg?auto=compress&cs=tinysrgb&w=1600`
**Description:** Designer working with fabric, measurements and sketches at a work table. Verify it loads; if not, use the fallback below.
**Fallback URL:** `https://images.pexels.com/photos/4620843/pexels-photo-4620843.jpeg?auto=compress&cs=tinysrgb&w=1600` (person sketching/designing apparel)
Use with a dark overlay for readable white hero text.

---

### Tech Pack Type Cards (8 cards)
**Do NOT use stock photos here.** Use styled placeholder blocks instead — a light-grey (`--bg-light`) box with a centered label in the brand style, e.g.:
- "Jacket & Outerwear — Technical Sketch"
- "Technical Pant — Technical Sketch"
- "Workwear & Uniform — Technical Sketch"
- "Tactical Apparel — Technical Sketch"
- "Base Layer & Activewear — Technical Sketch"
- "Fleece & Mid-Layer — Technical Sketch"
- "Headwear — Technical Sketch"
- "Custom & Hybrid — Technical Sketch"

Style them consistently (rounded corners, subtle border, centered uppercase label in `--body` grey) so the grid looks intentional and premium, not broken. These are placeholders for real BlackForgeX technical flat sketches to be added later.

---

### Banner Stripes (Sections 5–7)
These can use a supporting real photo of a design/development workspace if a banner background is wanted:
**File label:** banner-design-workspace
**URL:** `https://images.pexels.com/photos/4620774/pexels-photo-4620774.jpeg?auto=compress&cs=tinysrgb&w=1400`
**Description:** Apparel design / development workspace with sketches and materials. Verify it loads; if not, keep these banner sections as solid-color (dark or light-grey) backgrounds with text only — that also looks clean and on-brand.

---

## HONEST NOTE

This page depends more on real BlackForgeX assets than any other service page, because its core visual — technical flat sketches — is a bespoke deliverable that can't be faked with stock. The strong recommendation is: launch with clean styled placeholders in the card grid, and replace them with 2–3 real sample tech pack sketches as soon as they're available. Even a few real sketches will dramatically strengthen this page's credibility with brand owners and purchasing managers.

## LICENSE NOTE FOR CLAUDE CODE

The two hero/banner stock options are from Pexels (free commercial use, no attribution). Verify each URL loads before finalizing; if any returns an error, fall back to a solid-color background rather than substituting an unrelated or off-brand image. Never use AI-generated fake tech-pack sketches presented as real deliverables.
