# BLACKFORGEX — CUT & SEW MANUFACTURING PAGE
## Image Manifest (Free, Commercial-Use-Licensed — Pexels)

All images below are free-to-use, commercial-license, no-attribution-required stock photography from Pexels — genuine cutting/sewing action shots by male tailors, focused on the cutting and sewing process itself (not competitor images, not AI-generated, not generic fabric textures).

**How to use these:** Direct hotlink URLs — reference them directly in `<img src="...">` tags. No download or local file needed.

---

## SECTION → IMAGE MAPPING

### Split Hero — Image Box
**File label:** hero-tailor-cutting-fabric
**URL:** `https://images.pexels.com/photos/6765056/pexels-photo-6765056.jpeg?auto=compress&cs=tinysrgb&w=1260`
**Description:** Male tailor cutting fabric with scissors on a cutting table — direct, clear cutting-process shot.

---

### Full Bleed Image Hero (Section 2)
**File label:** fullhero-man-cutting-fabric
**URL:** `https://images.pexels.com/photos/5830663/pexels-photo-5830663.jpeg?auto=compress&cs=tinysrgb&w=1600`
**Description:** Man cutting fabric — wide-format shot suitable for a full-bleed background with dark overlay for text.

---

### Split Image Banner — Panel 1 (Technical Pattern Development)
**File label:** panel-hands-cutting-cloth
**URL:** `https://images.pexels.com/photos/2973399/pexels-photo-2973399.jpeg?auto=compress&cs=tinysrgb&w=900`
**Description:** Close-up of hands cutting white cloth near a sewing machine — pattern/cutting precision focus.

---

### Split Image Banner — Panel 2 (Custom Cut & Sew Trims and Finishing)
**File label:** panel-man-cutting-fabric-alt
**URL:** `https://images.pexels.com/photos/5830663/pexels-photo-5830663.jpeg?auto=compress&cs=tinysrgb&w=900`
**Description:** Reuse of the cutting shot at a different crop/size for the second panel — keeps visual consistency across the split banner.

---

### Guidance Banner (Section 5)
**File label:** guidance-fabric-rolls
**URL:** `https://images.pexels.com/photos/236748/pexels-photo-236748.jpeg?auto=compress&cs=tinysrgb&w=1600`
**Description:** Fabric rolls staged for production — no people, works well as a supporting background for this text-forward banner section.

---

### Factory Banner (Section 6)
**File label:** factory-tailor-cutting-fabric
**URL:** `https://images.pexels.com/photos/6765056/pexels-photo-6765056.jpeg?auto=compress&cs=tinysrgb&w=1600`
**Description:** Reuse of the tailor cutting fabric shot for the factory-floor banner section.

---

### Product Row (4 image slots, Section 7)
**File label 1:** product-tailor-cutting-01
**URL:** `https://images.pexels.com/photos/6765056/pexels-photo-6765056.jpeg?auto=compress&cs=tinysrgb&w=500`

**File label 2:** product-man-cutting-fabric-02
**URL:** `https://images.pexels.com/photos/5830663/pexels-photo-5830663.jpeg?auto=compress&cs=tinysrgb&w=500`

**File label 3:** product-hands-cutting-cloth-03
**URL:** `https://images.pexels.com/photos/2973399/pexels-photo-2973399.jpeg?auto=compress&cs=tinysrgb&w=500`

**File label 4:** product-fabric-rolls-04
**URL:** `https://images.pexels.com/photos/236748/pexels-photo-236748.jpeg?auto=compress&cs=tinysrgb&w=500`

---

### Services Grid (4 cards, Section 8)
**Card 1 — Cut & Sew Manufacturing:** reuse `hero-tailor-cutting-fabric` (6765056)
**Card 2 — Cut & Sew Basic Programs:** reuse `fullhero-man-cutting-fabric` (5830663)
**Card 3 — Technical Pattern & Sample Development:** reuse `panel-hands-cutting-cloth` (2973399)
**Card 4 — Specialized Construction & Tailoring:** reuse `guidance-fabric-rolls` (236748)

---

## HONEST NOTE ON REUSE

Only 4 genuinely relevant free cutting/sewing images were found (all male tailors doing cutting work, matching the "mostly male" and "cutting and sewing focus" direction set earlier in this project). They're reused across multiple sections at different crop sizes to keep visual consistency without introducing unrelated imagery. Once real BlackForgeX factory photography is available, prioritize replacing these first — this page reuses the same 4 images more than any other page built so far, so it will benefit the most from real photos.

## LICENSE NOTE FOR CLAUDE CODE

All images above are sourced from Pexels (pexels.com), free for commercial use, no attribution required. Not competitor images, not AI-generated.
