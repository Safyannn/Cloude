# BLACKFORGEX — SUBLIMATION PRINTING PAGE
## Image Manifest (Free, Commercial-Use-Licensed — Pexels)

All images below are free-to-use, commercial-license, no-attribution-required stock photography from Pexels — genuine sublimation/heat-press printing process shots or finished printed garments (not competitor images, not AI-generated).

**Honest note:** Free stock libraries have far fewer dedicated "sublimation printing" process photos than screen printing. These 4 are the most directly relevant real matches found. For the gallery section specifically (which the competitor filled with 5 product images), real BlackForgeX sublimation samples would represent the work far better than generic stock — treat these as placeholders until then.

**How to use these:** Direct hotlink URLs — reference them directly in `<img src="...">` tags. No download or local file needed.

---

## SECTION → IMAGE MAPPING

### Hero Section
**File label:** hero-fabric-printing-studio
**URL:** `https://images.pexels.com/photos/5727002/pexels-photo-5727002.jpeg?auto=compress&cs=tinysrgb&w=1600`
**Description:** Close-up of a professional printer printing custom artwork onto fabric in a studio setting — directly relevant to the sublimation printing process.

---

### Full-Color Intro Banner
**File label:** banner-finished-printed-tshirt
**URL:** `https://images.pexels.com/photos/6667014/pexels-photo-6667014.jpeg?auto=compress&cs=tinysrgb&w=1400`
**Description:** Person holding up a finished full-color printed t-shirt — shows the end result of a sublimation-style print.

---

### Method Stripe 2 — Cut-and-Sew Sublimation
**File label:** stripe-heat-press-tshirt-01
**URL:** `https://images.pexels.com/photos/7703649/pexels-photo-7703649.jpeg?auto=compress&cs=tinysrgb&w=900`
**Description:** Close-up of a graphic t-shirt being pressed/ironed — heat-press-adjacent process shot.

---

### Method Stripe 3 — Blank Garment Sublimation
**File label:** stripe-heat-press-tshirt-02
**URL:** `https://images.pexels.com/photos/7703684/pexels-photo-7703684.jpeg?auto=compress&cs=tinysrgb&w=900`
**Description:** Person pressing/ironing a garment — second heat-press-adjacent process shot for visual variety.

---

### Gallery Section
**File label:** gallery-sublimation-samples
**Note:** Only 4 genuinely relevant free images were found (listed above, reusable here). This section is the strongest candidate for real BlackForgeX photography — actual sublimated garment samples would represent the work far more convincingly than any available free stock. Recommend prioritizing real photos here over the other sections.

---

## LICENSE NOTE FOR CLAUDE CODE

All images above are sourced from Pexels (pexels.com), which grants a free license for commercial use with no attribution required. These are NOT competitor images and NOT AI-generated.

If BlackForgeX provides real product photography later (actual sublimated garments, print samples, or press-in-action shots), prioritize replacing these placeholders — starting with the gallery section — using this mapping as the placement guide.
