# BLACKFORGEX — EMBROIDERY PAGE
## Image Manifest (Free, Commercial-Use-Licensed — Pexels)

All images below are free-to-use, commercial-license, no-attribution-required stock photography from Pexels — genuine embroidery machine and stitching process shots (not competitor images, not AI-generated).

**How to use these:** Direct hotlink URLs — reference them directly in `<img src="...">` tags. No download or local file needed.

**Note on brand colors:** Some embroidery thread photos are naturally colorful (spools of many colors). For this page that's acceptable since it depicts the actual material (thread), not a design choice — but prefer the machine/stitching-process shots for the main hero and banners to stay closest to the red/black/white/grey brand tone, and keep the colorful-thread shots to smaller card slots.

---

## SECTION → IMAGE MAPPING

### Hero Section
**File label:** hero-embroidery-machine-stitching
**URL:** `https://images.pexels.com/photos/6153778/pexels-photo-6153778.jpeg?auto=compress&cs=tinysrgb&w=1600`
**Description:** Industrial embroidery machine stitching a design — direct, on-topic hero image. Use with a dark overlay so white hero text stays readable.

---

### Embroidery-Type Card 1 — Flat Embroidery
**File label:** card-flat-embroidery-machine
**URL:** `https://images.pexels.com/photos/9964261/pexels-photo-9964261.jpeg?auto=compress&cs=tinysrgb&w=900`
**Description:** Close-up of an embroidery machine stitching flat onto fabric.

---

### Embroidery-Type Card 2 — 3D Puff Embroidery
**File label:** card-embroidery-detail-cap
**URL:** `https://images.pexels.com/photos/7679720/pexels-photo-7679720.jpeg?auto=compress&cs=tinysrgb&w=900`
**Description:** Detailed embroidery/stitching close-up. Note: not specifically a puff-embroidery cap shot (free options are limited) — closest relevant match. Replace with a real BlackForgeX puff-embroidered cap photo when available.

---

### Embroidery-Type Card 3 — Custom Patches & Appliqué
**File label:** card-embroidery-thread-detail
**URL:** `https://images.pexels.com/photos/6153354/pexels-photo-6153354.jpeg?auto=compress&cs=tinysrgb&w=900`
**Description:** Embroidery machine with thread detail — stands in for patch/appliqué production.

---

### Embroidery-Type Card 4 — Chenille & Specialty Embroidery
**File label:** card-embroidery-thread-spools
**URL:** `https://images.pexels.com/photos/6injection.jpeg`
**FALLBACK URL (use this):** `https://images.pexels.com/photos/8112199/pexels-photo-8112199.jpeg?auto=compress&cs=tinysrgb&w=900`
**Description:** Colorful embroidery thread spools / specialty thread — fits the "specialty embroidery" theme. (Ignore the first malformed URL line above; use the FALLBACK URL.)

---

### Banner Stripe 1 — Digitizing
**File label:** banner-embroidery-machine-closeup
**URL:** `https://images.pexels.com/photos/6153778/pexels-photo-6153778.jpeg?auto=compress&cs=tinysrgb&w=1400`
**Description:** Reuse of the hero embroidery machine shot at banner crop — reinforces the "machine precision / digitizing" message.

---

## HONEST NOTE ON IMAGE AVAILABILITY

Free stock libraries have a decent number of embroidery-machine and thread photos, but very few that specifically show puff embroidery, chenille, or finished patches on branded apparel. The card images are the closest relevant free matches. This page is a strong candidate for real BlackForgeX embroidery photography — actual finished embroidered garments and your own machines would represent the work far better than generic stock. Prioritize replacing the card images first when real photos are available.

## LICENSE NOTE FOR CLAUDE CODE

All images above are sourced from Pexels (pexels.com), free for commercial use, no attribution required. Not competitor images, not AI-generated. Verify each URL loads before finalizing; if any returns an error, flag it rather than substituting an unrelated or off-brand image.
